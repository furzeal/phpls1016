<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Puhasta';
$_lang['error_log'] = 'Veateadete logi';
$_lang['error_log_desc'] = 'MODX Revolution-i veateadete logi:';
$_lang['error_log_download'] = 'Download Error Log ([[+size]])';
$_lang['error_log_too_large'] = 'The error log at <em>[[+name]]</em> is too large to be viewed. You can download it via the button below.';
$_lang['system_events'] = 'Süsteemi Event-id';
$_lang['priority'] = 'Prioriteet';